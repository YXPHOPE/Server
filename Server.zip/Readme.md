## File Server

By listening to 0.0.0.0:80 (changable), you can access your file on server computer at another device as long as they are in the same LAN.

## File Browser

image

music + lrc lyric

video + subtitle

document: doc, xls, txt, html

## Remote Control

control windows system remotely

Operation supported:
- On computer: mouse, keyboard
- On mobile: one finger to click, scroll, long press to right click or drag.